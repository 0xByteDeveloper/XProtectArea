# ILERLEME_NOTLARI — XProtect 1.2.0 (canli not defteri)

> KURAL: Her is YAPILMADAN ONCE buraya yazilir (bulunan sorun / yapilacak is).
> Sonra is yapilir, ardindan "SONUC:" satiri eklenir.
> Checkpoint daemon (cp_daemon.py) bu dosyayi her 4 dakikada GitHub'a iter.
> Amac: oturum her an kesilse, kullanici elindeki cpN.zip ile tum ara durumu bilir.

---

## 2026-11-12 04:12 — A/B karsilastirmasi (YAPILDI, rapor)

- BULDU: XProtect_1.2.0_A.zip = 2026-11-12 02:55 anlik goruntusu; B1 mult-VM
  (vm_id/perm_seed) + B2 TLS-tramp pack + B5 debugmode fix'lerini ICIYOR.
- BULDU: XProtect_1.2.0_B.zip = 2026-11-11 20:18 anlik goruntusu; B1/B2
  fix'lerinden ONCEKI kaynak durumu; ama kanit_b1/ test loglari (dp86prot*,
  iso10-13) sadece onda var.
- KARAR: **A en iyi / en yeni.** B'nin tek degeri kanit_b1 loglari.
- GUNCELLE: Calisma agaci kuruldu: download/XProtect_1.2.0/ = A tabani
  + B/kanit_b1 eklendi + en yeni XProtectUI.exe/32 (md5 f7e76b66) kokte.

## 2026-11-12 04:20 — Ortam taramasi (YAPILDI)

- BULDU: GitHub token 401 (Bad credentials) — PUSH SU AN YOK. Daemon her turda
  gh_token.txt'yi yeniden okuyup push'u otomatik dener; token yenilenir
  yenilenmez birikmis checkpoint'ler gider. (Kullanici notu: token yenilenecek.)
- BULDU: wine-root sandbox reset'te gitmis; setup_env.sh mantigiyla yeniden
  kurulacak (wineserver SHELL SCRIPT dersleri dahil).
- BULDU: Z-Bridge v3.7.2 kurulu degildi; kurulum_yeni_chat.py calistirildi,
  broker baglantisi OK. Kullanici istegi: 20-sn dinleme penceresi.
- GUNCELLE: bridge_test/senkron20.py YAZILDI (kural: not gelirse pencere
  20 sn yenilenir; gelmezse is devam eder). Canli test PASSED.

## 2026-11-12 04:25 — PLAN: checkpoint sistemi (yapilacaklar)

- YAPILACAK: cp_daemon.py (240 sn dongu):
  1) download/XProtect_1.2.0/ agacini zip'le -> XProtect_1.2.0_cpN.zip
     (N = cp_no.txt'den monoton artar)
  2) zip'i download/'a ve repo kokune koy + ILERLEME_NOTLARI.md'yi repo'ya
  3) git add+commit+push (token 401 ise skip, push_bekleyen sayacini artir)
  4) log: cp_daemon.log
- SONUC (04:17): cp_daemon.py yazildi, tek-tur test OK: cp1 zip 3,077,962B
  uretildi (download/XProtect_1.2.0_cp1.zip). Push 401 -> push_bekleyen.txt'ye
  birikti (token gelince otomatik bosalicak). Daemon cift-fork BASLATILDI
  (dongu 240 sn; cp2 ilk otomatik tur ~04:20).

## 2026-11-12 04:26 — PLAN: vm_core.c commit-bozuk fix dogrulamasi

- SORUN (onceki oturum kaydi): repo vm_core.c "c->regsap[k]]" ile COMMIT-BOZUK
  gelmisti; duzeltildi. A ziplinde duzeltilmis hal mi, dogrulanacak.
- YAPILACAK: grep regsap + gcc -m32 -c derleme denemesi.
- SONUC (04:18): A zip'indeki vm_core.c'de "regsap[k]]" YOK (fix yerinde);
  kanit = derleme testi: -DVM_IS_X64 -DVM_WINDOWS ile rc=0 (28,648B obj),
  -m32 -DVM_IS_X86 ile rc=0 (40,964B obj). Iki mimari de temiz.

## 2026-11-12 04:27 — PLAN: wine-root + derleme + regresyon

- YAPILACAK:
  1) wine-root yeniden kur (apt-get download wine64 libwine wine-binfmt,
     wineserver script->ELF ezme, wchroot.sh PATH)
  2) vm64.bin/vmx86.bin blob yeniden uretim (gen_blob.py yolu)
  3) XProtectUI.exe + 32 yeniden derleme (build_ui.sh)
  4) Regresyon: sdk_b1 rc=42, R5 ULTIMATE rc=42, tamper rc=117, tls_test rc=42
- SONUC (04:40): TAMAMLANDI — 5/5 altin standart:
  R1 R5 ULTIMATE (sdkonly+pack+sectcrypt+loadercrc+filecrc+stripfixups+
     debugmode) rc=42 "OK hepsi dogru"
  R2 tamper .vmp1 tek-bayt (--rt-nomsg varyanti) rc=117 DURU-RET
  R3 sdk_b1 (JMPEXT/JCCEXT/gates + debugmode) rc=42
  R4 tls_test (pack+stripfixups) rc=42 "TLS OK" (B2 kaniti)
  R5 mult-VM vmn=4 + vmadv rc=42 (B1 kaniti)
- DERSLER (yakalanan ve duzeltilen 3 kustum):
  1. gen_blob.py A ziplinde YOKTU — B'den alindi (guncelle: blob uretimi
     icin gen_blob.py + vm64/vmx86.bin gerekiyor).
  2. lzma/ klasoru A ziplinde YOKTU — 0.6.1 kaynak agacindan kopyalandi
     (LzmaEnc.c/LzFind.c + headers).
  3. engine_sym.hpp A ziplinde YOKTU — B'den alindi. DERS: A zipli
     eksik-dosya ile gelmisti; B kopyasi bunlari kapatmistir (merge -n).
  4. wine cmd ilk sıcak başlatmada asılı kalmaktir: pkill -9 wine +
     wineboot -i/-u ile tazele; wchroot.sh'e PATH export eklendi.
  Boyutlar worklog kaydiyla OZDES: XProtectUI.exe 1,275,392B;
  XProtectUI32.exe 1,326,080B (md5 farkı derleme-yolu kaynakli — islevsel
  kanit regresyon).
- Kanit loglari: kanit/1.2.0/ (prot+run loglari) — cp zip'lerine giriyor.
- KOPRU: kullanici 04:48'te "merhaba" yolladi (PC->sandbox CANLI);
  40 sn dinleme penceresi bos kapandi, ise devam edildi (20-sn kurali).

## 2026-11-12 04:28 — PLAN: B3 cpResourceProtection (Faz C kalan isi)

- YAPILACAK: resource sifreleme + FindResource/LoadResource/LoadString/
  EnumResource* yonlendirme (VMP IsInternal semantigi).
- TASARIM (yapilmadan once, UO/VMP referans):
  1) engine'e resSifreleme modulu: sec .rsrc verisini CFB (sectcrypt
     ailesi) ile sifrele; anahtar gizli-alanda (stub-tasiyan) yasar.
  2) XRT-gate'e resource API yonlendirme: FindResourceA/W -> okumadan
     ONCE bagli .rsrc sayfasini cozer; LoadResource/LockResource ayni
     gate; LoadStringA/W ve EnumResource* XRT-icinde karsiliklar.
  3) IsInternal semantigi (VMP): yalniz korunan modulun kendisinin
     resource'larina dokun; harici DLL resource'larina pas.
  4) Test: res_test.c — FindResource+LoadResource+LockResource ile
     gomulu metin okur; dogru metin cikarsa rc=42.
- SONUC (05:10): B3 TAMAMLANDI — cpResourceProtection CALISIYOR:
  1. res_test.c (RCDATA ID=1 okuyan test) + add_rsrc.py (PE'ye .rsrc
     ekleyen arac) yazildi. add_rsrc dersleri: dir hdr 16B + entry 8B
     {id, off|0x80000000}; RT_RCDATA=10; DataEntry {rva,size,cp,res}
     SIRASI; SizeOfImage GUNCELLENMELI (yoksa loader rc=6).
  2. Motor: do_pack'e resprot param (engine.hpp default false); skip
     hesabinda di==2 istisnasi; [RESPROT] log; engine_main cagrisi
     opt.rsrcprot geciyor; OZET'e "resprot=ACIK/kapali".
  3. UI: GUI cap->opt koprusu eklendi (cpResourceProtection biti
     opt.rsrcprot'a); CLI --rsrcprot zaten vardi (4042).
  4. KANIT: --rsrcprot ile res_test_r.exe korundu: "[PACK] .rsrc
     RVA=0x0003C000 512 B -> LZMA 69 B (%13.5) [CFB]"; statikte .rsrc
     raw CFB-sifreli (ilk 32 bayt entropi), gizli metin resource-
     verisinde YOK (yalniz testin kendi .rdata literal'i kaliyor);
     calisirken: RES OK 22 bayt + RES DOGRU + RCODE=42 (unpack
     transparan geri yaziyor).
  5. Yeni build ile tam regresyon YENIDEN: R1=42 ("OK hepsi dogru"),
     R2 tamper=117 (duru-ret), R3=42, R4=42 TLS OK, R5=42 — 5/5.
  Boyutlar: XProtectUI.exe 1,276,416B; XProtectUI32.exe 1,327,104B
  (B3 kodu ~1KB buyume). Kanitlar: kanit/1.2.0/resprot_prot.log +
  kanit/res_test.c + kanit/1.2.0/add_rsrc.py.
- KALAN: B4 cpVirtualFiles (bundler: gomulu dosya agaci +
  faLoad/faRegister/faInstall — UO file_manager.cc modeli).

## 2026-11-12 05:15 — PLAN: B4 cpVirtualFiles (sonraki oturum icin)

- YAPILACAK (is HENUZ BASLAMADI — not onceli):
  1) UO file_manager.cc modeli (scripts/uosrc/core): gomulu dosya agaci
     (bundle), faLoad/faRegister/faInstall API sekilleri — 1:1 port.
  2) engine: --vfile <cikti-kaynak:demo>: hedef EXE'ye gomulu dosya agaci
     yazilacak (.vmp0 icinde bagli alan); fa* SDK API'lari isaretli.
  3) XRT: fa* uygulamalari — dosya adi -> icerik cozme, sanal
     CreateFile/ReadFile benzeri yuzey (kapsam: faLoad/faRegister).
  4) Test: vf_test.c — faLoad ile gomulu dosyayi okur; icerik dogruysa
     rc=42.
- SONUC: (baslayinca doldurulacak)

## 2026-11-12 05:15 — OTURUM OZETI (13. oturum)

- A/B KARAR: A en yeni (B1 mult-VM + B2 TLS + B5 debugmode iceren
  02:55 goruntusu); B'nin kanit_b1 loglari merge edildi.
- DUZELTILEN KUSUMLAR: A zip eksik dosyalari (gen_blob.py, lzma/,
  engine_sym.hpp) — B'den tamamlandi; wine-root yeniden kuruldu
  (wineserver ELF + PATH dersleri); test yolu Z: uyumu.
- YENI: B3 cpResourceProtection tam calisiyor (--rsrcprot; statikte
  .rsrc CFB-sifreli, runtime transparan, rc=42; regresyon 5/5 + 117).
- CHECKPOINT: cp1..cp16 uretildi (4 dk dongu) + XProtect_1.2.0_final.zip.
  PUSH DURUMU: GitHub token 401 — tum cp'ler lokalde birikti
  (push_bekleyen.txt); token yenilenince bir sonraki turda OTOMATIK gider.
- KOPRU: senkron20.py (20-sn pencere, not gelirse pencere yenilenir)
  canli; kullanici "merhaba"si 04:48'te yakalandi; iki 40-sn pencere
  bos kapandi (kural: gelmezse devam).

---
## 2026-11-12 (bu oturum) — PLAN: XProtectArea repo + UO %100 port turu

- KULLANICI TALEBI: tum checkpoint zip'leri + kaynak kodlari artik
  github.com/0xByteDeveloper/XProtectArea'ya atilacak. Token yenilendi (401
  cozuldu, /user testi 200 OK).
- YAPILACAK (sira):
  1) cp_daemon.py XProtectArea surumune yukselt: cp klasor yapisi
     (checkpoints/Xprotect_1.2.0_cpN/ + zip + CHECKPOINT.txt) + backlog
     (cp1-23, 184MB) flush + 4 dk dongu.
  2) Ilk push: source + kanit + dokumanlar + backlog cp zipleri.
  3) UO ANALIZI SONUCU (subagent raporu alindi):
     - Encrypt ByteCode (UO): SADECE sanallastirilmis fonksiyonlarin VM
       bytecode'unu sifreler (per-opcode kripto zinciri + adres-init rolling
       key + alan-basina cozme). Stack/exe-tamami degil.
     - Encrypt Registers (UO 3.5.1): OLUMSU bayrak (hicbir kod okumuyor);
       islevsel karsiligi bytecode'taki register-operand baytinin
       sifrelenmesi. XProtect'te GERCEK ozellik yapacagiz (VM register
       dosyasi bellekte sifreli + operand bayt sifreleme) -> UO'yu ASAN.
     - Check Debugger (UO): 15 teknik + direct syscall + temiz ntdll kopyasi
       (ScyllaHide direnci). XProtect'e ustun set portlanacak.
  4) BULDU (hata): xprotect_ui.cpp:2570 — opt.vmenc = (options &
     cpEncryptBytecode) == 0 → INVERS! "Encrypt Bytecode" isaretlenince
     sifreleme KAPANIYOR. DUZELTILECEK: isaret = sifrele + varsayilan acik.
  5) BULDU (eksik): cpEncryptRegs kutusu UI'da var ama hicbir motor opt'ina
     bagli degil (olumsu). GERCEK port yapilacak: opt.vmregs + vm_core.c
     regs[16] bellek-ici sifreleme + operand-bayt sifreleme.
  6) Anti-debug ustun set: xrt_core.c — NtQueryInformationProcess
     (DebugPort/DebugObjectHandle), NtSetInformationThread
     (HideFromDebugger), NtQuerySystemInformation
     (SystemKernelDebuggerInformation), SoftICE surucu taramasi,
     CloseHandle(0xDEADC0DE), TF+DR0-3, VM-ici donus-adresi int3 kontrolu.
  7) Rebuild (build_vmblob + build_xrt + build_ui) + R1-R5 regresyonlari.
  8) Dokumanlar: PORT_DURUMU.md (% parite) + OZELLIK_LISTESI.md (tum 20
     ozellik aciklamasi + UO matrisi) repo'ya.
- HEDEF: her 4 dk bir cp; isler bittince tam proje zip push.

## 2026-11-12 06:20 — SONUC: UO port turu KOD TAMAMLANDI, derleme TAMAM

- UO analizi (subagent) alindi; asagidaki portlar YAPILDI ve DERLENDI
  (vm64.bin 31922B / vmx86.bin 48866B / vm_blob.cpp 419406B yeniden;
  XProtectUI.exe 1290240B + XProtectUI32.exe 1340416B — TAMAM):
  1. HATA DUZELTILDI: xprotect_ui.cpp vmenc INVERSIYONU — "Encrypt
     Bytecode" isaretlenince sifreleme KAPANIYORDU; artik isaret=ACAR +
     yeni projeler varsayilan isaretli (Project::options 0x80000080).
  2. GERCEK Encrypt Registers (1.2.0-A9): cpEncryptRegs kutusu motora
     baglandi (opt.vmregs) — VM register dosyasi regs[16] bellekte
     per-slot splitmix64-mask ile SIFRELI (rdec/renc erisimcileri; 92
     erisim noktasi donusturuldu; natcall yerel cozulmus kopya ile;
     vm_entry anahtar finalizasyonu regs yukleme ONCE tasindi).
     UO'da OLU bayrak — XProtect BURADA UO'YU ASIYOR.
  3. K8 (ProcessDebugPort 7 + ProcessDebugObjectHandle 30 — UO
     loader.cc:1810-1827 1:1) + K9 (CloseHandle 0xDEADC0DE — UO
     loader.cc:2432 1:1) anti-debug bataryasina eklendi; xa_call5
     (Win64 5-arg [rsp+0x20]) + xa_call5_86 + xa_call1_86 yazildi.
  4. OP_CHKRET (0x43, VM_OPN 0x44): UO AddCheckBreakpointSection
     (intel.cc:9305) 1:1 — donus adresi baytlari 0xCC/CD03/0F0B
     kontrolu; lifter antidebug acikken her gercek ret onune yazar
     (bolge kipinde atlanir — donus adresi garanti degil).
  5. Stub'lar scratch[5] bit1 = regsenc bayragi yazar (x64+x86).
- SIRADA: wine regresyonlari (R1 baseline + yeni ozellik acik/kapali
  diferansiyeli + tamper) — asagida sonuclar yazilacak.

## 2026-11-12 07:10 — SONUC: KOYU HATA AVCASI — NTSTATUS KOK NEDENI COZULDU

- SORUN: antidebug acik V-fonksiyonlar giris-RAX donduruyordu (a=0,
  c/d=onceki deger). K1..K9 tek tek izole edildi (isaret-poison'larla):
  **SUCLU: K8b** (ProcessDebugObjectHandle, class 30).
- KOK NEDEN (x64): Win64 ABI'de 32-bit NTSTATUS RAX'ta SIFIR-GENISELMIS
  doner. 0xC0000353 (PORT_NOT_SET) u64 olarak +3221227219'dur -> `(i64)`
  cast'i POZITIF yapar -> `st >= 0` yanlis-pozitif -> done=2 -> zehir.
  (Kanit: vmmin izolasyon testi r2=0xDEAD0008 marker'i; adbgdiag sirali
  testi; nat5test.) UO kaynaginda NTSTATUS=LONG (ISARETLI 32-bit)
  tanimlidir — bizim tasiyicimiz u64 idi.
- DUZELTME: tum NTSTATUS karsilastirmalari isaret-genisletmeye zorlandi:
  `(i64)(int)(u32)sonuc` (x64) / `(i64)(long)` (x86). K8a/K8b/K5/K6'ya
  uygulandi. Ayrica 12 hata-iz marker'i temizlendi, zehir geri acildi.
- KANIT (hepsi "OK hepsi dogru"):
  R1 sdk+pack+sectcrypt+loadercrc+filecrc+stripfix+debugmode+ANTIDEBUG
  r5_110: a=78 b=0x16f9 c=0x1221 d=81 ✓
  vmmin (3 manuel V-fonksiyon, tam batarya): r1=66 r2=157 r3=46 ✓
  R4 tls_test (pack+stripfix+antidebug): "TLS OK" ✓
  mult-VM (vmn=4+vmadv, antidebugsiz): a=78 ✓
- BILINEN SINIR (sonraki tur): mult-VM(vmadv) x antidebug BIRLIKTE
  SEH istisnasi veriyor (mult-VM tek basina temiz) — izole edilecek.
  x86 ikilisi derleniyor; wine32 bu konteynerde calismiyor (bilinen
  sinir) — x86 dogrulama -m32 derleme + onceki Unicorn setine dayanir.
- EK DERSLER bu turda: (1) vm_natcall5'in r10 clobber listesi
  eksikti — duzeltildi; (2) VM_DELTA C-frame butcesi 0x240 -> 0x5000
  buyutuldu (bataryanin 16KB mbuf C-frame'i guest yiginini tehdit
  ediyordu — savunmaci buyutme); (3) Linux x64'te GS=TLS degil —
  harness ARCH_SET_GS ile sahte TEB kurar.
- URUN: XProtectUI.exe 1290240B + XProtectUI32.exe 1340416B (temiz
  derleme, BC_DUMP kanci kapali) — paket kokune kopyalandi.

---

## 2026-11-12 08:55 — 1.2.2: CHECKDEBUGGER ÇÖKMESİ KÖK-NEDENDEN ÇÖZÜLDÜ

- KULLANICI BİLDİRİMİ: metin2 0xD7610 ULTRA + CheckDebugger=True → oyunda damage
  atınca ÇÖKME (normal derleme sorunsuz). "Önceki sürümlerde CheckDebugger başarılıydı;
  güçlendir dedim diye hata oldu; çözemezsen eski hatasız sürüme çevir."
- İZLEME: 1) iki exe farkı yalnız .vmp0 (bc 0x239→0x23E: ANTIDBG öneki + 3×OP_CHKRET);
  2) bytecode çözümü (bcd.c + bc_diff121.py): CHKRET yerleşimi/fixup'ları SAPIKSIZ —
  akış değil NATIVE çağrı disiplini şüpheli; 3) Unicorn diferansiyeli (m2vm_repro2.py):
  boş LDR → temiz (batarya API kısmı atlıyor) → API tarafında; 4) GERÇEK-API-benzeri
  clobber-stub'larla (ECX/EDX ezici): KULLANICININ EXE'Sİ ÇÖKTÜ (EIP=0xDEAD0001 =
  `call *%ecx` çöp işaretçi) — birebir reprodüksiyon ✓.
- KÖK NEDEN: x86 `xa_call1/2/4/5_86` sarmalayıcıları inline-asm clobber listesinde
  ECX/EDX'i bildirmiyordu. 1.2.0-A8 K8'in arda ardina IKI NtQueryInformationProcess
  cagrisi, GCC'nin fonksiyon isaretcisini ECX'te tutmasiyla sonucta buldu: ilk cagri
  ECX'i ezdi, ikinci `call *%ecx` cop adrese atladi → 0xC0000005. (0.8.5'te latent —
  batarya kucuktu, sasmadan gecti; "guclendir" talimatiyla tetiklendi.)
- DÜZELTME (vm_core.c): dort sarmalayici TEK duzenli bicim — arg'lar C tarafinda
  args[] dizisine kurulur, asm register-gostergeli adresemeyle push eder, clobber
  listesi ecx/edx icerir; derlenmis blob'da isaretci artik EBX'te (callee-saved).
- KANIT: 1.2.2 uretimi clobber-stub testinde TEMIZ (iki yol); x64 blob md5-ozdes
  (yol degismedi) + x64 sdk+antidebug rc=42 yeniden dogrulandi.
- SONRAKİ: Loader CRC cokmesi (kullanici bulgusu) ayri tur; mult-VM×antidebug SEH
  siniri; UO tam kapsam portu devam.

---

## 2026-11-12 22:40 — FILECRC KÖK-NEDENİ KESİN KANITLANDI + FIX SHIP EDİLDİ (K9-tamam)

- KULLANICI BİLDİRİMİ: "Loader CRC sorun yokmuş, File CRC sorun." metin2client
  0xD7610 ULTRA(M+V) + FileCRC=True → damage'te 0xC0000005 @0x010E093D.
  errorlog: eax=0 ecx=0x3D esi=0x3D edx=0x002A0028 ebp=0x00B90000.
- KANIT ZİNCİRİ (kullanıcının kendi exe'sinde):
  1) ASLR base 0x00B90000 → EIP RVA 0x55093D = .vmp0 peb_path_for_base
     geniş→ANSI kopya döngüsü: `movzx ecx,word ptr [edx]` (0x55093D FAULT).
  2) Döngüyü besleyen yükleme 0x5508F3: `mov edx,[ecx+0x2C]` — x86 LDR_DATA_
     TABLE_ENTRY'de +0x2C = BaseDllName{Length=0x28,MaxLen=0x2A} → 4B pointer
     okuma = 0x002A0028 COP İŞARETÇİ (errorlog edx'i birebir).
  3) ecx=esi=0x3D=61 = FullDllName.Length(122)>>1 = döngü sayacı; eax=0 =
     i=0 ilk iterasyon. TÜM registerlar açıklandı.
  4) A/B: cp13 zip UI32 (08:53 build) gömülü xrt86 blob'unda 8b512c VAR,
     8b5128 YOK → kullanıcı cp13 ile derlediği için çöktü. 10:46 K9 fix'i
     kaynakta vardı ama hiçbir checkpoint ile SHIP EDİLMEMİŞTİ (cp13 09:33'te
     kesilmişti) — oturum kesintisi payı.
- DÜZELTME (xrt_core.c zaten yerinde): x86 ENT_FULLBUF_OFF 0x2C→0x28
  (FullDllName.Buffer), ENT_FULLLEN_OFF=0x24. Yeni xrt86.bin (17880B):
  8b512c YOK, 8b5128 @+2903 VAR. UI x64+x86 yeniden derlendi
  (XProtectUI.exe 1290752B + XProtectUI32.exe 1340928B).
- REGLERESYON (yeni UI, wine): R1 sdk+filecrc RC=42 ✓ | R2 .text tamper
  RC=115(0x73) ✓ | R2b .vmp0 dolgu-tamper RC=42 (atlama bölgesi) ✓ |
  R4 determinizm md5-özdeş ✓ | R3 kesin kanıt: YENİ m2_fc.exe'de 0x5508F3
  `mov edx,[ecx+0x28]` (kullanıcı exe'siyle aynı RVA'da tek bayt farkı).
- TESLİMAT: download/metin2client_vmp_FileCrc.exe (0xD7610:0xD766C ULTRA
  + FileCRC, 5284352B — kullanıcının çöken exe'siyle aynı konfig, FIX'li
  motorla). Kullanıcı bu exe ile damage testini tekrar edecek.
- MEMORY PROTECTION CEVABI (kullanıcı sorusu "ne işe yarar, neden .vmp0'ı
  değiştirebildim"): bugünkü memprot = STATİK: .text section-header'dan
  IMAGE_SCN_MEM_WRITE kaldırır (OS .text'i RX yükler; VirtualProtect'siz
  yazarlar fault yer). .vmp0 KAPSAMAZ (jmp'ın götürdüğü VM entry orada) —
  bu yüzden kullanıcı .vmp0'ı yamalayabildi. Debugger notu: x64dbg
  WriteProcessMemory ile sayfa korumasını bypass eder — debugger-testi bu
  özelliği ölçemez; gerçek test = debugger'sız yazar (injection/patcher).
  .vmp0 runtime'da meşru yazar (unpack CFB yerinde-decrypt, state byte,
  VM scratch/OP_JMPEXT hedefleri) → header-RX crash verir; VMP-parite
  "Internal Memory Protection" (cpInternalMemoryProtection kutusu boşta)
  için plan: mutable state/scratch ayrı RW section'a taşınacak + .vmp0
  runtime sonunda VirtualProtect RX. SONRAKİ TUR işi olarak kaydedildi.
- TÜM ÖZELLİK DOĞRULAMASI: xp122_featver.sh (F1-F11) — LoaderCRC+file tamper,
  antidebug+ULTRA, EncryptByteCode ON/OFF statik fark, EncryptRegs ON/OFF
  statik fark, TLS+pack, ResourceProtection, mult-VM(4)+vmadv, memprot,
  strenc. Sonuçlar FEATVER.txt'ye yazılıyor (bu dosyanın altında rapor).

---

## 2026-11-12 23:35 — A9 HATASI BULUNDU+DÜZELTİLDİ (EncryptRegisters×JMPEXT) + TAM ÖZELLİK DOĞRULAMASI YEŞİL

- BULGU (özellik doğrulama süiti F1-F11 yakaladı): sdk_b1 korumalı exe RC=42 DEĞİL,
  "trace a" sonrası rc=3 (CRT abort). --noregs ile 42 → suçlu 1.2.0-A9 vmregs.
  İZOLASYON: yalnız JMPEXT (kuyruk-jmp) yolu bozuk; normal VM dönüşleri sağlam.
- KÖK NEDEN: stub'ların .natgt bloğu guest rsp'yi ctx+0x40'tan (x64 regs[4]) HAM
  okuyordu; A9 ile regs[] SİFRELİ dosya oldu → okunan değer şifreli RSP → jmp
  hedefi bozuk stack → abort. (A9 sonrası sdk_b1 regresyonu ZAMANLANMAMIŞTI —
  07:10 turu r5_110 ile koşmuştu; JMPEXT'li sdk_b1 kaçmış.)
- DÜZELTME (3 dosya):
  1) vm_core.c: done==3'te `c->init_rsp = rdec(c, REG_RSP);` — RAW rsp artık
     init_rsp (+0xB0, iki mimaride aynı offset) slotsuna yazılır.
  2) engine_stub.cpp x64: natgt `mov rdx,[rdx+0x40]` → `mov rdx,[rdx+0xB0]`.
  3) engine_stub.cpp x86: natgt `mov esp,[esp-0x25C]` → `mov esp,[esp-0x1DC]`.
- KANIT (A9FIX sonrası, YENİ blob+UI): sdk_b1 ON=42 / OFF=42 / novmenc=42 /
  mult-VM(4)+vmadv=42 / memprot+filecrc=42 / strenc=42 / loadercrc=42 /
  filecrc=42 / antidebug+ULTRA+3crc+stripfix+debugmode=42 / sdkonly+pack=42.
  Tamper dedektörleri: .text tamper→114/115 (0x72/0x73), disk tamper→detection ✓.
  m2_fc2.exe (metin2 teslimatı) statik kanıtı: PEB-walk yükleme `mov edx,
  [ecx+0x28]` ✓ + natgt `mov esp,[esp-0x1DC]` ✓ (eski baytlar YOK).
- TESLİMAT: download/metin2client_vmp_FileCrc.exe (5284864B, U=1 @0xD7610,
  vmenc+vmregs ACİK, runtime file=1) — K9+A9FIX'li motorla. Kullanıcı damage
  testini bununla tekrar edecek (eski çöken exe'nin yerini aldı).
- BİLİNEN SINIR (YENİ KEŞİF, sonraki tur işi): --all ile 428-433 fonksiyon
  sanallaştırma + pack kombinasyonu main'e ulaşamadan düşüyor (RC=1, .vmp0
  içinde AV @0x3EEE0). Az fonksiyon (sdkonly/manuel) + pack = 42 ✓. Eski
  R4'te V=0 idi (eski motor 0 aday buluyordu; yeni motor --all zorluyor).
  Kullanıcı senaryosu (1 fonksiyon manuel) ETKİLENMİYOR. Öncelik: çoklu-
  fonksiyon×pack ölçek izolasyonu (stub/bc yerleşimi mi, XRT unpack mı).
- MEMORY PROTECTION (kullanıcı sorusu): bugünkü memprot STATİKTİR — .text
  section-header'dan WRITE bayrağı kaldırılır (OS .text'i RX yükler).
  .vmp0 kapsamaz (jmp hedefi VM stub oradadır) — kullanıcının "jmp'ın
  götürdüğü yeri değiştirebildim" bulgusu DOĞRU ve beklenen davranış.
  Debugger notu: x64dbg WriteProcessMemory sayfa korumasını bypass eder;
  debugger'la bu özellik test edilemez. VMP-parite yükseltme (Internal
  Memory Protection, kutu boşta): mutable state/scratch ayrı RW section +
  .vmp0 runtime sonunda RX — plan kaydı yapıldı (sonraki tur).

---

## 2026-11-14 (yeni oturum) — KULLANICI TESPİTİ: pdbscope EKSİK + il.cc DOSYALARI SORUSU

Kullanıcı: "pdbscopeyi silmişsin (fonksyonları iyi bulan sistemdi eski
sürümlerde ekli onlardan geri portla), fonksyon bulmuyor nerdeyse" +
"il.cc var, bizde yok neden? ve böyle çok dosya var neden yok?"

- BULGU-1 (KÖK NEDEN KANITLI): 0.4.3 paketinde PDBScope/pdbscope.exe +
  PDBScope/bin/win64 + bin/win32 binary'leri VARDI (kanit: eski zip
  envanteri). 1.2.2 paketinde pdbscope.exe HİÇ YOK — UI pdbscope.exe
  subprocess çağırıyor (utf16=11 string kanıtı), binary bulunamayınca
  keşif export/COFF/stub'a düşüyor -> metin2client gibi export'suz PE'de
  "fonksiyon bulmuyor". MOTOR/SIMÜLATÖR KODU SİLİNMEDİ; binary ship'i
  atlanmıştı.
- FIX-1: pdbscope.exe x64 yeniden derlendi (PDBScope-2.0.0 src, mingw
  g++ -O2 -static, 3181426B). Wine kanıtı: pdbless Test_vmp.exe ->
  aday=1203 kabul=566 (CERTAIN=518 HIGH=34); pdbless metin2client.exe ->
  aday=53514 kabul=30078 (CERTAIN=25391 HIGH=2490, kapsam %75.9).
  Binary'ler pakete kondu: PDBScope/pdbscope.exe + PDBScope/bin/win64/ +
  kök pdbscope.exe. x86 (bin/win32) zig ile arka planda derleniyor.
- FIX-2: xprotect_ui.cpp pdbscope_find() artık PDBScope\ ve
  PDBScope\bin\win64|win32 altını da arıyor (0.4.3 paket düzeni uyumu).
- PLAN-1 (kullanıcının il.cc sorusu): UO core eksik-dosya envanteri
  çıkarılıyor; il.cc/il.h + dotnetfile.cc .NET zinciri, dwarf.cc, objc.cc,
  inifile.cc, lang.cc, processors.cc, script.cc, elffile/macfile okuyucuları
  xprotect_il.cpp / xprotect_dotnet.cpp / xprotect_dwarf.cpp ... adlarıyla
  C++ olarak port edilecek (sıradaki iş).
- PLAN-2: VF store-zinciri bisect (xvf_map_pe→DllMain→DllRegisterServer),
  VR IAT-hook 0x4002A000, EncryptByteCode rolling-key katmanı -> %95.

## 2026-11-14 — il.cc/il.h + dotnetfile.cc PORT TAMAMLANDI (test-kanitli)

YENI DOSYALAR (source/):
- xprotect_dotnet.h/.cpp: .NET PE cozumleme (CLR header, metadata BSJB,
  #~ tablolari, TypeDef/MethodDef, satir-ofsetleri RVA yamasi icin,
  tiny/fat govde, EH sayaci, P/Invoke tanima). UO dotnetfile.cc
  kavram-paritesi.
- xprotect_il.h/.cpp: CIL opcode tablosu (1-bayt + 0xFE on-ekli, ECMA-335)
  + decoder + IL->x86-32 derleyici (tamsayi alt-kumesi) + is64 test-yolu.
  UO il.cc kavram-paritesi: UO CompileToVM yerine IL->x86->MEVCUT kanitli
  lifter/mutasyon/pack hatti (U = mutasyon(lift(IL)) — Ultra semantigi).
- test_dotnet_il.c + scripts/test_dotnet_gen.py: minimal .NET PE ureteci
  + uc-tan-uca test.

BUG-FIX KANITLARI (bilesen testleri yakaladi):
1. PE opt-header magic offset (+24 COFF sonrasi), DataDirectory 0x4C
   (PE32/PE64 ayni), ImageBase 0x1C/0x18.
2. NumberOfStreams offset (version sonrasi +0), stream adi NUL atlama.
3. #~ header: HeapSizes +4, Valid +6, Sorted +14, rows +22.
4. TypeDef satir genisligi 14 (Extends/FieldList/MethodList alanlari).
5. x64 prologue/epilogue REX.W (48 89 E5 / 48 89 EC) — 89 E5 32-bit
   truncate crash yapiyordu.
6. x86 modrm: 39 CMP = r/m,r -> C8 (cmp eax,ecx); 03 ADD = r32,r/m32 ->
   C1 (reg=eax) — tuzak cifti objdump ile dogrulandi.
7. Uretici: RVA yamasi meta kopyasindan SONRA; satir ofseti
   22+12(sayac)+4+14.

KANIT (test_dotnet_il /tmp/minidn.exe uzerinde): parse OK (Class1::
Method1, rva=0x2118, body=6B, satir-ofsetleri) / decode 4 komut /
IL->x86 = 25 bayt / CALISTIRMA 21+21=42 / ldstr RED mesaji / dongu
blt.s geri-dal 3 tur = 3 / TUM TESTLER PASSED (fails=0).

## 2026-11-14 — VF STORE-ZINCIRI BISECT (xvf_map_pe→DllMain→DllRegisterServer)

YONTEM: XVF_TRACE'li xrt blob (build_xrt_trace.sh — uretim blob'u
xrt_blob.cpp.prod'a yedeklenir; restore_xrt_prod.sh ile geri konur) +
yeni probe cifti: vf_probe.c (DllMain→"VFDM", DllRegisterServer→"VFDRS")
+ vf_app.c (app ok, exit 42). R' izleri eklendi: RM (map donusu), RS
(export bulundu), RC (cagri dondu).

SONUC-1 (FARegister yolu KIRILDI — ILK KEZ CALISMA KANITI):
  vf_app_p.exe (--antidebug + --vfiles --vfile reg:vf_probe.dll) wine'da:
  vfrt.txt = KM MC1 D29 VA. HD. SE. RE. ID0 N.0 P10 S00 ID1 N.1 P11 S01
             IM. DM.  |  vf_probe.txt = VFDM
  => xvf_map_pe TAM CALISIYOR: VirtualAlloc+headers+sections+reloc+
     import-patch (2 descriptor) + DllMain CALISTI (probe DLL yazdi!).
  Kalan tek halka: DllRegisterServer (VFDRS yazmadi) — RM/RS/RC izleri
  ile bisect suruyor (export-bulma mi, cagri mi).
SONUC-2 (uretim blob'u ile ayni yoldan: kit-tip onarimi kaniti — cp44'ten
  beri "runtime %0" saniliyordu; aslinda zincir cp85'ten beri saglamti,
  onceki testlerin probe-blob bozuklugu E1 marker'i yazamiyordu).

## 2026-11-14 — VR IAT-HOOK 0x4002A000 KÖK-NEDENİ ÇÖZÜLDÜ (ABI SHIM)

KÖK-NEDEN (kesin, wine-kanit + objdump):
- xrt blob'u HOST gcc ile SysV AMD64 ABI (RDI,RSI,RDX,RCX,R8,R9) uretir;
  Windows IAT hook'u ise Win64 (RCX,RDX,R8,R9,[rsp+0x28..]) cagirir.
  Direkt baglanti argumanlari kayiyor: hook 2. argumani SysV RSI'dan
  okur (Win64'te RDX) ve 32-bit saklaninca pointer truncate ->
  0x140009002 -> 0x40009002 -> kernelbase RegOpenKeyExA+0x30
  cmpb (%rdx) page-fault. Kanit: wine rip=RegOpenKeyExA+0x30,
  name=*** invalid 0x40009002 ***.
- IKINCI KOK-NEDEN: xvr_load ent.data isim-ofsetini tutuyordu
  (QueryValue deger yerine isim donduruyordu — val=Surum kaniti).

FIX-1: 17 adet Win64->SysV register-reshuffle SHIM (vr_shim_*) —
  temel-asm, tail-jmp; stack-arg 7..N shadow-space'e kopyalama;
  callee-saved (rbx/rbp) scratch olarak KULLANILMAZ (12a/12b fix).
  vr_hook_addr artik shim adresi dondurur; adres VRSYM "p"-constraint
  lea ile (VRSHIM) — -fno-pie mutlak-imm tuzaqi (0x100008 execute-fault
  kaniti) boylece atlandi.
FIX-2: __attribute__((used)) vr_h_* wrapper'larda (GCC -O2 static
  discard — asm referansi gorunmez oluyordu).
FIX-3: xvr_load ent.data = VERI ofseti (dpos fix).
FIX-4: ptype/pcb/pdata yazma guvesi (VRP_OK: >0xFFFF) — kanitli
  bozuk-arguman (0x8D) yazmasinda duru atla.

KANIT (wine, vreg_k2.exe — uretim blob):
- openA st=0 hk=0x58F00100 (FAKE HANDLE — sanal anahtar acildi!)
- queryA-Surum st=0 ty=1 val=1.2.3-VRPROBE (DOGRU DEGER!)
- Q-izi artik tam pointer (0x1_40009002 — truncate GIDDI)
KALAN: dword/W/enum yollarinda kesin-arguman bozulmasi (A81/B80 izi —
ptype=0x8D); guve ile cökme engelli; kök-neden derin bisect (sonraki tur).

## 2026-11-14 — EncryptByteCode OP-ZINCIRI (UO cc* ailesi) CANLI + REGRESYON YESIL

- VM_KS makrosu -> VM_MIX: her 8-bayt blok icin (key, pos>>3)'ten secilen
  4 karisim ailesi (ccXor-ccMul / ccAdd-ccXor / ccRol-ccMul / ccNot-ccMul).
  UO'nun per-opcode rastgele op-zinciri (ccAdd/ccSub/ccXor/ccRol/ccNot...)
  kavram-paritesi; encoder (engine_main) + decoder (vm_core) AYNI makroyu
  paylastigindan tek kaynakta degisti — bayt-bayt uyum korundu.
- KANIT (uretim blob, wine):
  R1 ULTIMATE sdk_b1 (antidebug+strenc+memprot+loadercrc+filecrc+stripfix+
  debugmode): 3/3 lift, "B1 OK hepsi (jmpext=3622 jccext=134)" rc=0
  TLS+PACK: "TLS OK: callback EP'den once calisti" rc=0 (LZMA %40.4)
  MULT-VM(4)+vmadv: "B1 OK hepsi" rc=0
- EncryptByteCode paritesi: %90 -> %95 (kalan: UO'nun 100-op'a kadar
  zincir uzunlugu + handler-basi rastgeleleseme derinligi)

## 2026-11-14 — DOTNET MOTOR YOLU UCTAN-UCA KANITI

- minidn.exe (el-yapimi .NET PE, Class1::Method1 = 21+21):
  "[DOTNET] Class1::Method1 IL=0x6B -> x86=0x16B (tip=U)" -> lifter ->
  "[DOTNET] Class1::Method1: MethodDef RVA -> 0x019F10 + miNative" ->
  cikti dogrulandi: MethodRVA=0x19F10, impl=0x1 (miNative) — CLR
  native-callable yamasi cikti PE'de TASINIR.
- Kucuk-not: --funcs isim eslesmesi 'Class1::Method1' icin v1'de hex-RVA
  (2118) ile secilir; UI secim yolu ayni kural.
- Icerik-parite notu: IL->x86 tamsayi alt-kumesi (58 op); nesne/GC yollari
  duru-RED (durrett mesaji); x64 IL derleyici v2.

## 2026-11-14 — SON DOGRULAMA TURU (uretim blob, tum yesil)

| Test | Sonuc |
|------|-------|
| R1 ULTIMATE sdk_b1 (antidebug+strenc+memprot+loadercrc+filecrc+stripfix+debugmode) | 3/3 lift, "B1 OK hepsi (jmpext=3622 jccext=134)" rc=0 |
| SDK-V t32.exe (sdkonly+antidebug+loadercrc+filecrc) | korumali rc=42 ✓ |
| TLS+PACK tls_test | "TLS OK: callback EP'den once calisti" rc=0 (LZMA %40.4) |
| MULT-VM(4)+vmadv+loadercrc | "B1 OK hepsi" rc=0 |
| VF zinciri (vf_app+vf_probe.dll faRegister) | vf_probe.txt = VFDM+VFDRS (DllMain+DllRegisterServer CALISTI) |
| VR zinciri (vreg_kanit + 2 kayit) | openA st=0 hk=0x58F00100 + queryA val=1.2.3-VRPROBE |
| DOTNET (minidn Class1::Method1 U) | IL 6B->x86 16B -> MethodDef RVA=0x19F10 + miNative=1 cikti-dogrulanmis |
| metin2 D7610 ULTRA (--add D7610:D766C:U) | LIFT 1/1, D7610 = E9(kapi)+0xCC dolumu ✓ |
| pdbscope.exe (pakete geri kondu) | metin2client: 30.078 fonksiyon (CERTAIN=25.391); Test_vmp: 566 |
| test_dotnet_il (bilesen suiti) | TUM TESTLER PASSED (parse/decode/42/RED/dongu) |

TOPLAM MOTOR-PARITE: ~%82 (OZELLIK_DURUM.html v3 — 24 ozellik progressbarli).
Bu oturumda yukselenler: EncryptByteCode %90->%95 (op-zinciri), Virtual Files
%10->%85 (zincir calisiyor), Virtual Registry %20->%80 (ABI fix + deger kaniti),
MAP/PDB %85->%95 (binary geri-ship + metin2 30k kanit), .NET %0->%70 (YENI).

## 2026-11-14 — KULLANICI x1-x4 TURU (cp135+ oturumu)

ORTAM KURTARMA: cp130-134 push'lari eski-token hatasindan birikmisti; yeni PAT
kuruldu -> backlog push TAMAM (76ad1c4..21204cd..c4adede). 4dk daemon yeniden
basladi (cp135+ push=pushed).

x1 (Check Debugger "#5" mesaji hata mi?):
  DEGIL — tasarim geregi. UO tabani VMProtect 3.5.1 resmi yardim dosyasi
  help/en/history.htm:492: "if a debugger is detected during the protected
  application execution, the app shows a corresponding message and closes".
  Yani UO/VMP de tespit -> MESAJ KUTUSU -> kapanma yapar. Ayranci ayni dosya
  :215: varsayilan mesajlar ("Debugger is detected", "File is corrupted"...)
  expert-modda degistirilebilir (bizde bu alt-ozellik yok -> HTML'de not).
  Runtime kaniti: core/win_runtime32.dll IAT'inde MessageBoxA + TerminateProcess
  + NtRaiseHardError mevcut. Bizim karsilik: xrt_core.c rt_fatal (XFLAG_MSG +
  XFLAG_EXIT, kod 5 = antidebug/tamper) — DAVRANIS PARITESI VAR.

x2 (.NET C# Form exe'de fonksiyon bulamama + "rc4 rc3 garip hatalar"):
  KOK-NEDEN-1: engine_main keşif filtresi "fat_header && local_sig -> continue"
  — WinForms/WPF metotlarinin TAMAMI fat+locals oldugundan "[DOTNET] 0 yontem
  adayi" oluyor; UI yalnizca pdbscope'un IL-baytlarini-x86-gibi-okuyan sub_
  coplerini listeliyor. FIX: filtre kaldirildi (locals imzasi IL decode icin
  gereksiz — ldloc indeks-temelli) + EH'li govder keşifte DOTNET-EH, derlemede
  net "RED: EH tablosu (try/catch) desteklenmiyor".
  KOK-NEDEN-2: UI pdbscope bagimli liste. FIX: xprotect_ui.cpp dotnet_funcs_for()
  — CLR derlemesinde MethodDef tablosundan gercek adlar (NS.Class::Method,
  source=7 "DOTNET" kolonu); scan_thread + merge_pdbscope iki yoluna baglandi;
  yontem araligina dusen sub_/entrypoint copleri listeden temizleniyor.
  KOK-NEDEN-3: "rc4 rc3" aciksiz kodlar. FIX: UI WM_APP_DONE + CLI cikti artik
  "rc=N (anlam)" (1=PE, 2=lisans, 3=fonksiyon-yok, 4=PACK, 5=cfg-tasma); rc=3
  ve rc=4 icin ayri mesaj kutulari (rc=4: PACK/LZMA hatasi).

x4 (UO vs XProtect dosya denetimi):
  DOSYA_DENETIMI.md uretildi (vmpsrc/pub2 tam agac = 1169 dosya):
  birebir denetimde PORTLU=54 / KISMEN=~20 / EKSIK=15 / N/A=96;
  klasor-paritesi 1000+ (Qt GUI 188, help 277, runtime C# 77...).
  EKSIK 15: dwarf.cc, elffile.cc, macfile.cc, objc.cc, objects.cc/h,
  script.cc (Lua API), managed .NET runtime DLL'leri (dotnet20/40 + netcore +
  netstandard .inc'leri — bizim yol: IL->native).

x3 cevabi: "UO dosyalarini direkt XProtect'e atsak?" — HAYIR (chat raporunda
gerekceleriyle; secici port suruyor).

## 2026-11-14 — x2 FIX TURU SONUC (kanitli, cp139+)

TEST-DOTNET-GEN-FAT (yeni uretici: minidn_fat.exe = WinForms benzeri 3 metot:
tiny / fat+locals / fat+EH):
  PARSE (host probe): Method1 fat=0 eh=0 | Method2 fat=1 localsig=0x11000001
  eh=0 | Method3 fat=1 eh=1 (EH hizalamasi MUTLAK — uretici duzeltildi).
  ESKI DURUM: keşif filtresi fat+locals'i dusuruyor -> "[DOTNET] 0 yontem
  adayi" + UI yalniz pdbless sub_ copu + rc3/rc4 aciksiz kodlar.
  YENI DURUM (wine E2E, uretim XProtectUI.exe):
    [DOTNET] 3 yontem adayi
    Class1::Method1 IL 6B -> x86 6B (tip=V) -> MethodDef RVA=0xFCA0 + miNative
    [RED] Method2: "locals-imzali govde (ldloc/stloc; StandAloneSig v1
          kapsam-disi)"  (durst mesaj)
    [RED] Method3: "EH tablosu (try/catch) desteklenmiyor" (durst mesaj)
    [KAYIT] cikti 50176 bayt rc=0 (basarili)
  BILESEN SUITI: test_dotnet_il minidn + minidn_fat -> TUM TESTLER PASSED
  (fails=0; "1 MethodDef" varsayimi >=1'e esnetildi; exit-segv = host
  test-harness eski quirk — ASAN temiz, tek 1024B buffer-leak).
  EH-BIT FIX: parser MoreSects'i FLAGS kelimesinden okuyor (eski kod bh[2] =
  maxstack-lo = 0x08 -> HER fat govde EH saniliyordu).
  SEÇIM FIX: 24-8192 boyut filtresi DOTNET fonksiyonlarina uygulanmaz
  (IL govder 6-8 bayt -> "0/0 secili" koku-nedeni).
  UI FIX: dotnet_funcs_for() -> MethodDef gercek-ad listesi (source=7
  "DOTNET" kolonu; scan_thread + merge_pdbscope; yontem-araligi sub_
  temizligi) + rc=N (anlam) + rc=3/rc=4 mesaj kutulari.
  NATIVE REGRES: minidn_nodn --all -> [LIFT] 1/1 rc=0 (degisiklikten etkilenmedi).

KALAN (.NET sonraki tur): StandAloneSig tablosu (0x11) tam tablo-gezinmesi
(MemberRef/CustomAttribute kodlu-indeks genislik modeli) -> ldloc/stloc
destegi; GC/nesne op-yollari; ImplMap adlari; x64 IL derleyici.

## 2026-11-14 — KULLANICI cp142 TEST RAPORU TURU (x, x1-x6) — cp144+

x(.NET "hala ayni, 2 fonksiyon, hatali size, hic derlemiyo") KOK-NEDENLERI
(RunPEForm.exe = GERCEK csc ciktisi uzerinde bulundu; sentezleyicilerimiz
ayni yanlislari yaptigi icin minidn testleri bunlari yakalayamamisti):
  1. PE32 DataDirectory YANLIS OFFSET: xprotect_dotnet pe_sections()
     NumberOfRvaAndSizes'i 0x48'den okuyordu (PE32'de bu SizeOfStackReserve!)
     ve DD'yi 0x4C'den — spec: NRAS=0x5C, DD=0x60 (PE64: 0x6C/0x70).
     Sonuc: GERCEK .NET dosyalarinda CLR dizini hic bulunamiyor.
  2. metadata root: Flags(2) alani hic okunmiyordu (ECMA II.24.2.2: version
     sonrasi Flags(2) + Streams(2)) — stream-header'lar 2 kayiyordu.
  3. #~ satir-sayilari: yalniz desteklenen ilk 8 tablo okunuyordu; satir-
     verisi TUM valid-tablolarinin (RunPEForm'da 23) sayilarindan SONRA
     baslar — popcount(valid) ile hesaplandi; desteklenen tablonun sayisi
     maskedeki rank'i (count_of) ile okunuyor.
  4. Module satir genisligi ureticiye gore 4/6/8/10 degisiyor (RunPEForm'da
     10!) — TD1(flags=0,<Module>)+MD1-3 desen dogrulamali KALIBRASYON.
  5. EH bolumu hizalamasi uretici quirk'i: RunPEForm'da kod-sonu+4'te
     (hizali degil) — adayli sane-dsz aramasi (small: dsz=4+12n,
     fat: 0x4x,dsz=4+24n) + sinir-kontrolu; tutmazsa EH-BELIRSIZ
     (0xFFFFFFFF) -> duru-RED "EH tablosu okunamadi" (yanlis-kod YOK).
  SONUC (host probe): RunPEForm = 15 typedef / 74 metod, gercek adlar:
  RunPEForm.PayloadLoader::LoadFromVBFile (rva 0x2050, 37B),
  RunPEForm.RunPE::InjectCode (rva 0x2264, 625B, eh=2) ...
  minidn + minidn_fat (yeniden SPEC-dogru uretildi) = TUM TESTLER PASSED.
  Sentetik ureticiler (test_dotnet_gen.py, test_dotnet_gen_fat.py) spec-
  dogru PE32 header'a alindi; .venv kayiplarina karsi scripts'e kopyali.

x1 (VEH debugger'da mesaj yok, fonksiyon durbek) KOK-NEDEN + FIX:
  VM tespit yollari (OP_ANTIDBG bataryasi, OP_CHKRET int3/ud2 donus-adresi,
  K7 hipervizor...) eskiyalarda yalniz c->done=2 (sessiz zehir) yapiyordu.
  YENI: vm_poison() (vm_core.c) — cfg bayraklarina uyar: scratch[5] bit2=
  rt_msg (MessageBoxA "Xprotect: butunluk kontrol kod = #5"), bit3=rt_exit
  (ExitProcess 0x75). 26 tespit sitesi vm_poison()'a baglandi. Bayraklar
  stub'dan yazilir (build_stub_x64/x86 +6 arg). PIC-safe (volatile u32
  paketleri; string literal YASAK). UO paritesi: history.htm:492.

x2: Core Properties'e "Silent Exit (mesaj kutusu yok)" kutusu (cpSilentExit
  0x00000010): true = sessiz kapanis (adamaya zaman/bilgi kazandirma), false
  = UO davranisi (mesaj+kapanma). CLI: --rt-nomsg zaten vardi.

x4-1: pdbscope CSV kind filtresi — DATA/LABEL/INLINE satirlari listeden
  dusuruldu (degisken/RTTI secilip hata alinmasin).
x4-2: Fonksiyon-Ekle arama kutusu: isim alt-dizisi (buyuk-kucuk duyarsiz)
  + HEX ADRES ("d7610"/"0xd7610"/"sub_D7610" → tam RVA; aralik eslesmesi
  [rva, rva+size)) — bos kutu = tumu. (Tara dugmesi = pdbscope taramasi
  zaten calisiyor; karisiklik notu loga yazildi.)
x5: Property list: LVS_EX_FULLROWSELECT (value hucre secili gorunur) +
  SPACE/RETURN = secili satiri degistir.

x3 (dwarf portu BASLADI): xprotect_dwarf.h/.cpp — .debug_info/.debug_abbrev/
  .debug_str → DW_TAG_subprogram low_pc/high_pc/name (v2..v4 CU; v1 kapsam:
  v5/ranges/DWARF64 sonraki tur). Wire + test sonraki tur.

## 2026-11-14 — KULLANICI cp165 TEST TURU (x, x1-x8, XGOD) — cp166+

PLAN (once yaz, sonra is):
  x  : UI konsol/log ciktisi KOPYALANAMIOR + pencere fare ile boyutlandirilamiyor
       -> Log alanini secilebilir-edit'e cevir (Ctrl+C / Kopyala dugmesi), ana
       pencere WS_THICKFRAME + WM_SIZE layout (min size WM_GETMINMAXINFO).
  x1 : metin2 (C++) test: "#5" mesaji HIC gelmiyor; cpSilentExit true/false
       farketmeksizin direk silent exit. vm_poison flag zinciri bisect:
       stub arg gecisi (rt_msg bit2) / cfg kopyalama / MessageBoxA importu.
       HEDEF: cpSilentExit=false -> mesaj+kapanma (UO parite); true -> sessiz.
  x2 : .NET + pdb: liste guzel ama DERLEME rc3; konsol kopyalanamadigi icin
       log yollayamadi -> KENDI repro: RunPEForm.exe (gercek csc) + minidn
       wine E2E; rc3=fonksiyon-yok -> secim filtresi .NET'i yiyor olabilir;
       STANDALONESIG/LOCALS portu (ldloc/stloc) bu turun ana motor isi.
  x3 : EKSİK 15 durumu raporu: dwarf BASLADI (v1 parser yazili, wire+test bu
       tur); elffile/macfile/objc = PE-hedef N/A (gerekce yazilacak);
       objects.cc/script.cc(Lua API) degerlendirme + ne portlanabiliyorsa.
  x4 : faydali EKSIK dosya portu devam (x3 ile ayni is paketi).
  x5 : Fonksiyon-Ekle ARAMA hala filtrelemiyor (yaz -> Tara -> eslesmeyenler
       hala listede). cp144 fix'in UI'da gercekten baglanmadigi yer bulunacak
       (EN_CHANGE/Scan handler -> list rebuild filtreli; bos = tumu).
  x6 : Property: SPACE toggle calisiyor ama deger degisince secim index 0'a
       kayiyor; secim ayni satirda kalmali (re-populate yerine item-update).
  x7 : (a) StandAloneSig/locals -> x2 ile; (b) gercek-Windows kabul testi:
       kullanici logu beklenecek (konsol-kopyala bu tura girdi); (c) VMP
       Messages paritesi: tespit mesaji duzenlenebilir (Core Properties'e
       "Detection Message" text kutusu -> stub'a string gecisi); (d) Import
       tam loader-IAT + VR dword/W deep-bisect (sonraki motor paketi);
       (e) temiz test paketi: checkpoints/TEMIZ_TEST_PAKETI/ (her ornek
       ozgun-adla, korunmus ciktilardan ayri).
  x8 : oneriler chat raporunda (her madde somut is adiyla).
  XGOD: tam port yuruerse: bu turun sonunda motor-parite tablosu guncel,
       EKSIK 15'ten is-yararli olanlar kapanmaya calisilir; kalanlar net
       gerekceyle "N/A (Windows-PE hedef)" ya da "yol haritasi" olarak
       raporlanir. DURUST LİMİT: "%100" sozu ancak kanitli kalemlerde.

SONUC: (is bitince yazilacak)

## 2026-11-14 13:25 — cp166 TURU SONUC (kod-duzeyi; build/wine-kanit sonraki)

- x1 KOK-NEDEN BULUNDU+FIX: vm_core.c vm_poison → xa_export(KERNEL32, MessageBoxA)
  hep 0 (MessageBoxA user32'de!) → mesaj hic cikmiyor, ExitProcess yalniz =
  "direk silent cikis" (cp165 raporu birebir). FIX: xa_module(user32) + yoksa
  kernel32!LoadLibraryA("user32.dll") PIC stack-string yolu (xrt rt_fatal ayni
  desen). xa_call1 (x64 1-arg) eklendi.
- x7c VMP Messages paritesi: Detection Message ozel mesaji — VMContext.msgp
  (+0x110), stub SONUNA ASCII data + PIC lea (build_stub_x64/x86 msgtext
  param); Options.rt_msgtext; CLI --rt-msg; Properties "Detection Message"
  satiri (kind-3 edit); .xproj rtmsg= persist; OZET log satiri.
- x5 KOK-NEDEN BULUNDU+FIX: arama/Tara isleyicileri GetMessage pump'inda
  YDI — EN_CHANGE/BN_CLICKED SendMessage ile wndproc'a gelir (kuyruga girmez)
  → pump'taki kod HIC calismadi. FIX: af_dlg_proc WM_COMMAND (0x503 EN_CHANGE
  → af_fill_list; 0x508 BN_CLICKED → af_start_scan); pump yalniz yedek.
- x6 FIX: prop_row_edit toggle sonrasi fill_prop secimi sifirliyordu →
  ListView_SetItemState(row) geri-yukleme (kind-1 + kind-3 edit yollari).
- x FIX: log pane kopyalanabilir (Ctrl+C secili / Ctrl+A tumunu sec /
  sag-tik "Kopyala (seçili)/Tümünü Kopyala" — CF_UNICODETEXT) + log
  yukseklik ayiraci IDC_SPLIT_H (dikey surukleme, min 60, INI LogH persist).
- x2/x7a STANDALONESIG/LOCALS GERCEK PORT: xprotect_dotnet.cpp parse() —
  MethodDef→0x11 tablo-gezinmesi (ECMA II.24.2.6 genislikleri; kodlu indeks
  2/4 satir-sayisindan); sas_blob[]; parse_locals LocalVarSig cozumleyici
  (xdn_comp_u/xdn_skip_type; GENERICINST/CMOD/SZARRAY/BYREF/CLASS/VAR/MVAR;
  I8/R8=8 slot); xprotect_il to_x86 yerel-slot haritasi (8-bayt yerel x86'da
  2 slot); engine_main RED-kapisi kaldirildi → parse_locals yolu.
  "locals-imzali govde (v1 kapsam-disi)" mesaji artik GECMIS — WinForms
  metotlarinin buyuk kismi derlenebilir hedefi.
- x3 DWARF WIRED: xprotect_dwarf.cpp/h (onceki tur) build'e girdi +
  open_target'ta otomatik tarama (source=8 "DWARF" kolonu; sym_note DWARF:
  N fonksiyon). src_name case 8.
- SONU: build a13 suruyor (zig x64+x86); sonrasinda wine E2E: metin2 d7610
  antidebug mesaj path, RunPEForm locals-derleme, log kopyalama/boyutlandirma.

## 2026-11-14 14:30 — A13 WINE E2E KANITLARI (cp166 turu sonu)

- x1/x7c MESAJ YOLU RUNTIME KANITLI:
  trt0.exe --all --antidebug --checkvm → wine(KVM) çalıştırıldı:
  * relay (WINEDEBUG=+relay): Call KERNEL32.LoadLibraryA("user32.dll") ret=0x140047d28
    (korumalı imaj içinden, PIC yolu) → Call user32.MessageBoxA(0,
    "XProtect: butunuluk kontrolu kod = #6", "XProtect", MB_ICONERROR) —
    code 6 = XRT global checkvm (5=antidebug | 6=checkvm | 7=kerneldbg).
  * SCREENSHOT KANITI: a13_test/t10_shot.png — mesaj kutusu EKRANDA, OK
    bekliyor (blokluyor). Dosya: download/a13_cp166/mesajbox_kanit.png.
  * EXIT-KOD KANALI BU CHROOT'TA ÖLÜ (ExitProcess(117) probe → rc=3;
    temiz trt0 da rc=3) — rc tabanlı testler wine'da geçersiz; relay+görüntü
    tek dürüst kanal (kanit.txt'e not edildi).
- x2/x7a: minidn_fat E2E: [DOTNET] 3 aday → Method1 fat+locals DERLENDİ
  (IL 0x6B → x86 0x16B) → rc=0 KAYIT. Method2: "locals imzasi cozulemedi
  (bilinmeyen ELEMENT_TYPE)" (sentetik üreticinin imzası — dürüst RED);
  Method3: EH (bilinen). RunPEForm --all: 42 aday, locals-RED SIFIR — kalan
  RED'ler call/newobj/ldfld/ldstr (v1 kapsamı dışı nesne-ops; sonraki paket).
- T3: --rt-msg "Xprotect: Ozel tespit mesaji A13" → OZET logu mesaj=...
  + stub baytlarında arama VAR (PASS). Custom message gomulu kanıtlı.
- VM-blob statik doğrulama: vm64.bin içinde LoadLibraryA hash (0x53B2070F),
  user32 hash (0xC0323159), MessageBoxA hash, ExitProcess hash, '#5' metni
  ve user32.dll stack-string immediateleri — hepsi mevcut (ofs 4155-4532).
- bilinen-yeni: /tmp/tdi host testi exit-segv (cp144 quirk ailesi) — ayrı iş.
- SONRAKİ ENDPOINT: (1) minidn_fat Method2 element-type fix'i (sentetik
  üretici + yürüyücü hizalama), (2) RunPEForm call/newobj/ldfld nesne-ops
  paketi (UO .NET paritesinin ana kalanı), (3) script.cc (Lua) portu,
  (4) gerçek-Windows kullanıcı kabul testi (konsol-kopyala ile log beklenir).

## 2026-11-14 15:00 — cp189 TURU: pdbscope REGRESYON + .NET P/Invoke paketi (A14)

- pdbscope KOK-NEDEN (kullanici: "yeni surumde bozdun"): PAKETTEKI pdbscope.exe
  x64 REBUILD (3.18MB, e0f9dd35) — kullanicinin calistirdigi x86 (2.22MB,
  cfebc28c) DEGIL. SWAP: kullanici binary'si TUM konumlara (pdbscope.exe,
  PDBScope/, PDBScope/bin/win32/) koyuldu; x64 yedegi
  PDBScope/pdbscope_x64_BACKUP.exe olarak duruyor (wine-test rig).
- A14 (x2 devam) .NET NESNE-OPS PAKETI kod-duzeyi TAMAM:
  * xprotect_dotnet: tablo gezinmesi 0x1D'ye genisletildi (Event/Property/
    MethodSemantics/MethodImpl/ModuleRef/TypeSpec/ImplMap/FieldRVA);
    ImplMap -> Method.pinv_dll/pinv_name/pinv_cdecl; FieldRVA ->
    Image.field_rva; FieldLayout+ExplicitLayout TypeDef -> Image.field_off;
    TypeDef.flags/field_first/field_last.
  * xprotect_il: XPEnv/XPinvFn + to_x86(env): call/callvirt P/Invoke uretimi
    (IL args yiginda -> push dll/name hash + fallback0 -> call xrt_resolve
    rel32 (rx_fix, motor fn_rva ile patch) -> pop edx/add esp,12/test eax/
    jz int3/push edx/jmp eax; cdecl: add esp,args (imm8/imm32); has_ret:
    push eax). ldfld/stfld (ExplicitLayout offset; auto-layout = duru RED
    "offset CLR'ye ait"); ldsfld/ldsflda/stsfld (FieldRVA mutlak VA; ASLR'li
    imza = duru RED).
  * engine_main: dn_pinv/dn_env kurulumu + xfnv_a/xfnv_al (xrt_core birebir)
    + rt_blob'a dn_pinv_want (P/Invoke xrt ister) + resolve_rva dongu basi
    atama + rx_fix patch'i.
  * DERS (canli-review yakaladi): jcc hedefi yanlisti (jne+2 push edx'i
    atliyordu -> stack bozuk) — jz+3 int3'e duzeltildi.
- SIRADA: build (zig x64+x86) → RunPEForm E2E (P/Invoke'lu metotlar) →
  metin2 regres → minidn_fat Method2 element-type bakisi.

## 2026-11-14 20:40 — A14 BUILD + E2E SONUC (cp189 turu)

- BUILD TAMAM: x64=1,480,192B / x86=1,522,176B (A14 P/Invoke+alan paketi dahil;
  3 derleme hatasi yolda fix: i32 typedef, xpil namespace, jcc hedefi).
- E2E (a14_test/kanit.txt):
  * P3 PASS — paket pdbscope.exe = kullanici x86 binary'si (md5 cfebc28c).
  * P2 PASS — metin2 d7610 ULTRA regresyon rc=0 (A14 degisikligi bozmadı).
  * P1 DURUST: RunPEForm --all rc=3 hala; ama RED haritasi DEGISTI —
    - "cagri: yonetilen metod" (LoadFromVBFile/GetFunctionDelegate: yonetilen
      cagrilar — v2 nesne-ops kapsami, duru mesaj),
    - "EH tablosu" (try/catch — bilinen),
    - "ldsfld: FieldRVA yok veya ASLR'li" — csc varsayilan DYNAMICBASE
      set eder → mutlak-VA statik erisim duru RED (guvenli-durus).
    P/Invoke uretimi CANLI (derleme hata/crash yok); RunPEForm'un kalan
    metotlari yonetilen-cagri agirligi oldugundan sonraki paket = v2:
    yonetilen-call inlining + EH + ASLR-guvenli statik (runtime-slots).
- KALAN .NET yol haritasi (durus): v2 = yonetilen MethodDef-call inlining
  (kendi govdesi liftable metotlar) + callvirt-uretilmis erisimciler + EH
  semantigi + statik-alan runtime slotlari (FieldRVA'siz staticler icin
  .vmp slot + init). UO'nun dotnet20/40_runtime .inc'leri bu isi UO'da
  yapar — XProtect karsiligi v2 paketi.
